import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import './Chart.css'
function Chart() {

    const [chartData, setChartData] = useState([]);
    // const [filterData, setFilterData] = useState([]);
    const [demo, setDemo] = useState([]);

    // useEffect(() => {
    const fetchData = () => {
        console.log("Fetched Data called")
        fetch('/chartshow', {
            method: "get",
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json'
            }
        }).then(res => res.json())
            .then(result => {
                console.log("Result", result)
                // setChartData(result.data)
            })
    }


    // }, [])

    const chartShow = (type) => {
        console.log("Chart Show============================== Is ")
        var months = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"];
        var newArray = [];
        for (var i = 0; i < 12; i++) {
            var obj = new Object();
            obj.month = months[i]
            obj.Number = 0
            for (var j = 0; j < chartData.length; j++) {
                var field = chartData[j].Date.split("/");
                if (chartData[j].Type === type && i + 1 === parseInt(field[1], 10)) {
                    { obj.Number += parseInt(chartData[j].Number); }
                }
            }
            if (obj.Number !== 0) {
                newArray.push(obj)
            }
        }
        setDemo(newArray)
    }

    const chooseOption = (e) => {
        chartShow(e.target.value)
        // e.preventDefault();
        setFilterData([...new Set(chartData.map(element =>
            element.Type))]
        )
    }

    return (
        <div className="custom-select custom-select-sm mt-3" >
            {/* {console.log("1")} */}
            {
                fetchData()
                
            }
            <h1>Chart</h1>
            <label style={{ color: "red", margin: "30px" }} htmlFor="select">Select Type:
                            <select onFocus={(e) => chooseOption(e)} onClick={(e) => chooseOption(e)} className="custom-select custom-select-sm mt-3 select" name="types" id="types"  >
                    {

                        filterData.map((typeData, index) => {
                            return (

                                <option key={index} value={typeData}>{typeData}</option>
                            )
                        })
                    }
                    {/* {} */}
                </select>
            </label>

            <BarChart className=" custom-select custom-select-sm mt-3 chartBox" width={1300} height={400} data={demo}
                margin={{ top: 5, right: 30, left: 20, bottom: 5, }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend verticalAlign="top" height={36} />
                <Bar dataKey="Number" barSize={30} fill="#800000" />
            </BarChart>
            {/* {chartShow()} */}
            <h3 style={{ marginLeft: "130px", color: "red" }}>Developed By Praveen Pandey</h3>
        </div>
    )
}


export default Chart;
